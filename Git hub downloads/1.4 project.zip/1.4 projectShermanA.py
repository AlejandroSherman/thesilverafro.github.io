import matplotlib.pyplot as plt
import os.path
import numpy as np
import PIL
import PIL.ImageDraw

#Open Alex picture in numpy
directory = os.path.dirname(os.path.abspath(__file__))  
filepath_alex = os.path.join(directory, 'face.jpg')
alex_numpy = plt.imread(filepath_alex)

#Open tongue image in numpy
filepath_tongue = os.path.join(directory, 'tongue.JPG')
tongue_numpy = plt.imread(filepath_tongue)


# Converts Alex, and tongue numpy ima to PIL
tongue_image_pil = PIL.Image.fromarray(tongue_numpy)

alex_image_pil = PIL.Image.fromarray(alex_numpy)



# Makes sure tongue image fits 
tongue_img_fit = tongue_image_pil.resize((350,350))


# Places tongue image over eyes
alex_image_pil.paste(tongue_img_fit,(1414,1060))
alex_image_pil.paste(tongue_img_fit,(1414,1760))

# Adds a red circle and blue star
fig, ax = plt.subplots(1, 1)
ax.plot(1875,1550,'ro',ms=42.3)
ax.plot(1078,1516,'b*',ms=35.3)
ax.imshow(alex_image_pil, interpolation='none')

#Shows final image
fig.show()